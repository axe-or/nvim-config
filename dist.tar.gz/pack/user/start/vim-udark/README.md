# μDark
Small VS Dark inspired theme for Vim/Neovim.

# Installation
- Install as a regular vim plugin (Recommended). OR
- Put udark.vim into `~/.vim/colors` or `~/.config/nvim/colors`
